﻿namespace APIUsuarios.Domain
{
    public enum UserRole { ALUNO = 0, ADMIN = 1 }
}
