﻿namespace APIUsuarios.Domain
{
    public enum Role { ALUNO = 0, ADMIN = 1 }
}
