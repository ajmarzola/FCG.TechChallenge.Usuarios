﻿using System.Net;
using System.Net.Http.Json;
using System.Threading.Tasks;

public class UsersEndpointsTests : IClassFixture<CustomWebApplicationFactory>
{
    private readonly CustomWebApplicationFactory _factory;

    public UsersEndpointsTests(CustomWebApplicationFactory factory) => _factory = factory;

    [Fact]
    public async Task Admin_Can_List_Users()
    {
        var client = _factory.CreateClient();

        // Admin semeado pela factory
        var adminToken = await TestHelpers.LoginAndGetTokenAsync(client, "admin@test.local", "Admin@123");
        client.UseBearer(adminToken);

        var r = await client.GetAsync("/users?page=1&pageSize=10");
        r.StatusCode.Should().Be(HttpStatusCode.OK);

        var page = await r.Content.ReadFromJsonAsync<PagedResult<UserVm>>();
        page.Should().NotBeNull();
        page!.Items.Should().NotBeNull();
        page.Items.Should().NotBeEmpty();
    }

    [Fact]
    public async Task NonAdmin_Cannot_List_Users_403()
    {
        var client = _factory.CreateClient();

        // cria aluno
        var email = $"aluno_{Guid.NewGuid():N}@test.local";
        var register = new { email, senha = "Senha@123", nome = "Aluno x" };
        var r1 = await client.PostAsJsonAsync("/auth/register", register);
        r1.StatusCode.Should().Be(HttpStatusCode.Created);

        // login aluno
        var tokenAluno = await TestHelpers.LoginAndGetTokenAsync(client, email, "Senha@123");
        client.UseBearer(tokenAluno);

        // tenta listar
        var r = await client.GetAsync("/users");
        r.StatusCode.Should().Be(HttpStatusCode.Forbidden);
    }

    private record UserVm(Guid Id, string Email, string Nome, string Role, DateTime CreatedAtUtc, DateTime? UpdatedAtUtc);
    private record PagedResult<T>(IEnumerable<T> Items, int Total, int Page, int PageSize);
}
