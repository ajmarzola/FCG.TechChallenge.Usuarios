﻿using System.Net;
using System.Net.Http.Json;
using System.Text.Json;
using System.Threading.Tasks;

public class AuthEndpointsTests : IClassFixture<CustomWebApplicationFactory>
{
    private readonly CustomWebApplicationFactory _factory;

    public AuthEndpointsTests(CustomWebApplicationFactory factory) => _factory = factory;

    [Fact]
    public async Task Register_Then_Login_Then_Validate_Works()
    {
        var client = _factory.CreateClient();

        // 1) Registrar novo aluno
        var email = $"aluno_{Guid.NewGuid():N}@test.local";
        var register = new
        {
            email,
            senha = "Senha@123",
            nome = "Aluno Teste",
            role = "ALUNO" // opcional
        };

        var r1 = await client.PostAsJsonAsync("/auth/register", register);
        r1.StatusCode.Should().Be(HttpStatusCode.Created);

        // 2) Login
        var token = await TestHelpers.LoginAndGetTokenAsync(client, email, "Senha@123");
        token.Should().NotBeNullOrWhiteSpace();

        // 3) Validar token
        var r3 = await client.PostAsJsonAsync("/auth/validate", new { token });
        r3.StatusCode.Should().Be(HttpStatusCode.OK);

        var payload = await r3.Content.ReadFromJsonAsync<TokenValidateResponse>();
        payload.Should().NotBeNull();
        payload!.valid.Should().BeTrue();
        payload.claims.Should().ContainKey("role");
        payload.claims["role"].ToString().Should().Be("ALUNO");
    }

    private record TokenValidateResponse(bool valid, string? reason, Dictionary<string, object> claims);
}
