﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using APIUsuarios.Infrastructure.Data;

public class CustomWebApplicationFactory : WebApplicationFactory<Program>
{
    private SqliteConnection? _connection;

    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.UseEnvironment("Testing");

        builder.ConfigureAppConfiguration((ctx, cfg) =>
        {
            var mem = new Dictionary<string, string?>
            {
                ["ConnectionStrings:Sqlite"] = "Data Source=:memory:",
                ["Jwt:Issuer"] = "GamesPlatform",
                ["Jwt:Audience"] = "games-platform",
                ["Jwt:Key"] = "this-is-a-very-long-test-key-32-bytes-min-!", // >= 32 bytes
                ["Swagger:Enabled"] = "false",
                ["AdminSeed:Email"] = "admin@test.local",
                ["AdminSeed:Password"] = "Admin@123",
                ["AdminSeed:Nome"] = "Administrador Teste"
            };
            cfg.AddInMemoryCollection(mem);
        });

        builder.ConfigureServices(services =>
        {
            // Substitui o DbContext por SQLite in-memory
            var descriptor = services.SingleOrDefault(d => d.ServiceType == typeof(DbContextOptions<UsersDbContext>));
            if (descriptor is not null) services.Remove(descriptor);

            _connection = new SqliteConnection("Data Source=:memory:");
            _connection.Open();

            services.AddDbContext<UsersDbContext>(o => o.UseSqlite(_connection));

            // cria schema
            var sp = services.BuildServiceProvider();
            using var scope = sp.CreateScope();
            var db = scope.ServiceProvider.GetRequiredService<UsersDbContext>();
            db.Database.EnsureCreated();
        });
    }

    protected override void Dispose(bool disposing)
    {
        base.Dispose(disposing);
        if (disposing)
        {
            _connection?.Dispose();
            _connection = null;
        }
    }
}
